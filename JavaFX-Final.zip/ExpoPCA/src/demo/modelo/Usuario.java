package demo.modelo;

import java.util.HashMap;
import java.util.Map;

public class Usuario {

    private static final Map<String, Usuario> USERS = new HashMap<String, Usuario>();
    private String id= "";
    private String email = "";
    private String telefono = "";
    private boolean suscrito;
    private String direccion = "";

    public static Usuario of(String id) {
        Usuario user = USERS.get(id);
        if (user == null) {
            user = new Usuario(id);
            USERS.put(id, user);
        }
        return user;
    }

    public Usuario(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
    

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public boolean isSuscrito() {
        return suscrito;
    }

    public void setSuscrito(boolean suscrito) {
        this.suscrito = suscrito;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
