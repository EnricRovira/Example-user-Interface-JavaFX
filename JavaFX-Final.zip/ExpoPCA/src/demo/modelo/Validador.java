package demo.modelo;

import java.util.HashMap;
import java.util.Map;

public class Validador {
    private  static Map<String, String> USUARIOS = new HashMap<String, String>();
    static {
        USUARIOS.put("cerdo", "cerdo");
    }
    public static boolean validar(String user, String password){
        String validUserPassword = USUARIOS.get(user);
        return validUserPassword != null && validUserPassword.equals(password);
    }
    
}