
package controladores;

import Navegador.NavegadorPrivado;
import FuegosArtific.FuegosArtificiales;

import demo.Main;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import demo.modelo.Usuario;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Enric
 */
public class ControladorMenu extends AnchorPane implements Initializable {

    @FXML
    Button bPerfil;
    @FXML
    Button bFuegosArtificiales;
    @FXML
    Button bNavegador;
    @FXML
    Button bSalir;
    @FXML
    AnchorPane panelPrincipal;
    @FXML
    AnchorPane panelSecundario;

    private Main application;

    public void setApp(Main application) {
        this.application = application;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
    }

    public void IraPerfil(ActionEvent evento) {
           application.gotoPerfil();
    }

    public void lanzarNavegadorSeguro(ActionEvent evento) throws Exception {
        Stage navegador = new Stage();
        navegador.setResizable(false);
        navegador.setTitle("NavegadorSeguro");
        NavegadorPrivado navPriv = new NavegadorPrivado();
        navPriv.lanzarNavegador(navegador);

    }

    public void lanzarFuegos(ActionEvent evento) throws Exception {
        Stage verFuegos = new Stage();
        verFuegos.setResizable(false);
        verFuegos.setTitle("Fuegos Artificiales");
        FuegosArtificiales fuegos = new FuegosArtificiales();
        fuegos.lanzar(verFuegos);
        
        
    }

    public void Salir(ActionEvent evento) {
        application.gotoLogin();
    }

}
