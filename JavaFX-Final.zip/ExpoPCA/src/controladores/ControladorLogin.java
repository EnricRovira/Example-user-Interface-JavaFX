package controladores;

import demo.Main;
import java.awt.Color;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
/**
 *
 * @author Enric
 */
public class ControladorLogin extends AnchorPane implements Initializable {

    @FXML
    TextField Idusuario;
    @FXML
    PasswordField password;
    @FXML
    Button login;
    @FXML
    Label errorMessage;

    private Main application;
    
    
    public void setApp(Main application){
        this.application = application;
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        errorMessage.setText("");
        Idusuario.setPromptText("pca");
        password.setPromptText("etsisi");
        
    }
    
    
    public void processLogin(ActionEvent event) {
        if (application == null){
            errorMessage.setText("Hola " + Idusuario.getText());
        } else {
            if (!application.userLogging(Idusuario.getText(), password.getText())){
                errorMessage.setText("Usuario o Contraseña incorrecta");
				
            }
        }
    }
}

