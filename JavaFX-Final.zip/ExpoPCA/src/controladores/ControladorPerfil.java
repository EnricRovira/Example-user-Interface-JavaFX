package controladores;

import demo.Main;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import demo.modelo.Usuario;
import demo.modelo.Validador;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
/**
 *
 * @author Enric
 */
public class ControladorPerfil extends AnchorPane implements Initializable {

	@FXML
	private TextField usuario;
	@FXML
	private TextField telefono;
	@FXML
	private TextField email;
	@FXML
	private TextArea direccion;
	@FXML
	private CheckBox suscripcion;
	@FXML
	private Hyperlink logout;
	@FXML
	private Button guardar;

	@FXML
	private Label exito;

	@FXML
	Image image;
	@FXML
	Scene scene;
	@FXML
	Group root;
	@FXML
	ImageView view;
	@FXML
	Stage stage;

	private Main application;

	public void setApp(Main application) {
		this.application = application;
                Usuario loggedUser = application.getusuarioLogeado();
		usuario.setText(loggedUser.getId());
		email.setText(loggedUser.getEmail());
		telefono.setText(loggedUser.getTelefono());
		if (loggedUser.getDireccion() != null) {
			direccion.setText(loggedUser.getDireccion());
		}
		suscripcion.setSelected(loggedUser.isSuscrito());
		exito.setOpacity(0);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	public void processLogout(ActionEvent event) {
		if (application == null) {
			return;
		}
                application.gotoMenu();
	}

	public void guardarPerfil(ActionEvent event) {
		if (application == null) {
			animateMessage();
			return;
		}
		Usuario loggedUser = application.getusuarioLogeado();

		loggedUser.setEmail(email.getText());
		loggedUser.setTelefono(telefono.getText());
		loggedUser.setSuscrito(suscripcion.isSelected());
		loggedUser.setDireccion(direccion.getText());
		animateMessage();
	}

	public void limpiarPerfil(ActionEvent event) {
		if (application == null) {
			return;
		}
		email.setText("");
		telefono.setText("");
		suscripcion.setSelected(false);
		direccion.setText("");
		exito.setOpacity(0.0);

	}

	private void animateMessage() {
		FadeTransition ft = new FadeTransition(Duration.millis(1000), exito);
		ft.setFromValue(0.0);
		ft.setToValue(1);
		ft.play();
	}
}
